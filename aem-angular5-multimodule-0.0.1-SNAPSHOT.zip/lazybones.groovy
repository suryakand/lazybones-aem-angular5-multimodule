/*
 * #%L
 * AEM Lazybones Template for Angular 2 Application
 * %%
 * Copyright (C) 2018 Suryakand
 * %%
 * Free to use for opensource projects but, if you are using it for commercial project
 * Please add reference to Blog: http://suryakand-shinde.blogspot.com
 * #L%
 */
import uk.co.cacoethes.util.NameType
import org.apache.commons.io.FileUtils
import org.apache.commons.io.FilenameUtils

// Helper Functions
/**
 * Convert a String value to a Groovy truthy or falsy (blank) value.
 */
def toBoolean(String val) {
    val = val.toLowerCase()
    if (val.startsWith("n") || val.equals("false")) {
        return ''
    } else {
        return val
    }
}

/**
 * Ask the user a question expecting a yes/no/true/false response.
 */
def askBoolean(String message, String defaultValue, String propertyName) {
    String val = ask(message, defaultValue, propertyName)
    val = toBoolean(val)
    parentParams[propertyName] = val
    return val
}


/**
 * Ask the user a question expecting a yes/no/true/false response.
 */
def askBoolean(String message, String defaultValue) {
    String val = ask(message, defaultValue)
    return toBoolean(val)
}

// initialization
def props = [:]

// Core Maven Information
props.groupId = ask("Maven group ID for the generated project [com.suryakand.aem]: ", "com.suryakand.aem", "groupId")
props.artifactId = ask("Maven artifact ID for the generated reactor project [aem-angular5]: ", "aem-angular5", "artifactId")

def defaultBundleArtifactId = "${props.artifactId}.core";
props.bundleArtifactId = ask("Maven artifact ID for the generated bundle project [${defaultBundleArtifactId}]: ", defaultBundleArtifactId as String, "bundleArtifactId")

def defaultAppsArtifactId = "${props.artifactId}.ui.apps";
props.appsArtifactId = ask("Maven artifact ID for the generated apps project [${defaultAppsArtifactId}]: ", defaultAppsArtifactId as String, "appsArtifactId")

def defaultContentArtifactId = "${props.artifactId}.ui.content";
props.contentArtifactId = ask("Maven artifact ID for the generated content package project [${defaultContentArtifactId}]: ", defaultContentArtifactId as String, "contentArtifactId")

props.version = ask("Maven version for generated project [0.0.1-SNAPSHOT]: ", "0.0.1-SNAPSHOT", "version")

props.projectName = ask("AEM Project Name (No Spaces, No Special Chars) [ng5aem]: ", "ng5aem", "projectName")

props.projectDescription = ask("Human readable project desciption [My AEM Project]: ", "AEM Angular", "projectDescription")

FileUtils.moveDirectory(new File(templateDir, "ui.apps/src/main/content/jcr_root/apps/ngaem"), new File(templateDir, "ui.apps/src/main/content/jcr_root/apps/"+props.projectName))
FileUtils.moveDirectory(new File(templateDir, "ui.apps/src/main/content/jcr_root/etc/designs/ngaem"), new File(templateDir, "ui.apps/src/main/content/jcr_root/etc/designs/"+props.projectName))

FileUtils.moveDirectory(new File(templateDir, "ui.content/src/main/content/jcr_root/content/dam/ngaem"), new File(templateDir, "ui.content/src/main/content/jcr_root/content/dam/"+props.projectName))
FileUtils.moveDirectory(new File(templateDir, "ui.content/src/main/content/jcr_root/content/ngaem"), new File(templateDir, "ui.content/src/main/content/jcr_root/content/"+props.projectName))


println "Processing pom files..."
processTemplates "pom.xml", props
processTemplates "core/**/*", props

processTemplates "ui.apps/pom.xml", props
processTemplates "ui.apps/*.json", props
processTemplates "ui.apps/*.ts", props
processTemplates "ui.apps/*.js", props
processTemplates "ui.apps/src/main/content/jcr_root/apps/**/*", props
processTemplates "ui.apps/src/main/content/META-INF/**/*", props
processTemplates "ui.apps/src/template/*", props
processTemplates "ui.apps/src/main/content/jcr_root/etc/designs/**/.content.xml", props


processTemplates "ui.content/pom.xml", props
processTemplates "ui.content/**/.content.xml", props
processTemplates "ui.content/src/main/content/META-INF/**/*", props