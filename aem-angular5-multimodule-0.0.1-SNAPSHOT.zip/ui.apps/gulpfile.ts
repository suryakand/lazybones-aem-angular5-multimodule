"use strict";

const gulp = require("gulp");
const del = require("del");
const tsc = require("gulp-typescript");
const sourcemaps = require('gulp-sourcemaps');
const tsProject = tsc.createProject("tsconfig.json");
const tslint = require('gulp-tslint');
const path = require("path");
const tap = require("gulp-tap");

let clean = require('gulp-clean');
let replace = require('gulp-replace');

const appConfig = {
    tsSources: '/src/main/content/jcr_root/apps/${projectName}',
    tsBuildTarget: 'build',
    resourcesBuildTarget: "build",
    systemConfigTargetAem: 'src/main/content/jcr_root/apps/${projectName}/components/structure/page/clientlib'
}

let compileTs = function(source, destination) {
    let tsResult = gulp.src(source)
    .pipe(sourcemaps.init())
    .pipe(tsProject());
    return tsResult.js
    .pipe(sourcemaps.write(".", {sourceRoot: appConfig.tsSources}))
    .pipe(gulp.dest(destination));        
}

let buildLibs = function(destination) {
    return gulp.src([
        'core-js/client/shim.min.js',
        'systemjs/dist/system-polyfills.js',
        'systemjs/dist/system.src.js',
        'reflect-metadata/Reflect.js',
        'rxjs/**/*.js',
        'zone.js/dist/**',
        '@angular/**/bundles/**',
        'ng2-completer/ng2-completer.umd.js'
    ], {cwd: "node_modules/**"}) /* Glob required here. */
    .pipe(gulp.dest(destination));    
}

/**
* Remove build directory.
*/
gulp.task('clean', gulp.series((cb) => {
    return del(["build"], cb);
}));

gulp.task('clean-generated-files', gulp.series(function () {
    return gulp.src([
        'src/main/content/jcr_root/apps/${projectName}/components/**/*.component.js', 
        'src/main/content/jcr_root/apps/${projectName}/components/**/*.component.js.map',
        'src/main/content/jcr_root/apps/${projectName}/components/**/app.module.js',
        'src/main/content/jcr_root/apps/${projectName}/components/**/app.module.js.map',
        'src/main/content/jcr_root/apps/${projectName}/components/**/app.routing.js', 
        'src/main/content/jcr_root/apps/${projectName}/components/**/app.routing.js.map',
        'src/main/content/jcr_root/apps/${projectName}/components/content/main.js', 
        'src/main/content/jcr_root/apps/${projectName}/components/content/main.js.map',
        'src/main/content/jcr_root/apps/${projectName}/components/ui.tests/**/*.spec.js', 
    ], 
    {read: false, allowEmpty: true}).pipe(clean({force: true}));
}));

/**
* Lint all custom TypeScript files.
*/
gulp.task('tslint', gulp.series(() => {
    return gulp.src("src/**/*.ts")
    .pipe(tslint({
        formatter: 'prose'
    }))
    .pipe(tslint.report());
}));

/**
* AEM Build specific tasks (executed from maven)
*/
gulp.task("libs:aem", gulp.series(() => {
    return buildLibs("src/main/content/jcr_root/etc/designs/${projectName}/lib/");
})); 

gulp.task("resources:aem", gulp.series(() => {
    return gulp.src(["src/app/**/*", "!**/*.ts"])
    .pipe(gulp.dest('src/main/content/jcr_root/etc/designs/${projectName}/app'));
}));

gulp.task("compile:aem", gulp.series("tslint", () => {
    return compileTs("src/main/content/jcr_root/apps/${projectName}/components/**/*.ts",'src/main/content/jcr_root/apps/${projectName}/components');
}));

gulp.task('update-template-path:aem', gulp.series('compile:aem', 'resources:aem', () => {
    return gulp.src(['src/main/content/jcr_root/apps/${projectName}/components/**/*.component.js'])
    .pipe(tap(function(file) {
        var fileName = path.basename(file.path);
        let componentDir = path.dirname(file.path).split(path.sep).pop();
        return gulp.src(`src/main/content/jcr_root/apps/${projectName}/components/content/\${componentDir}/\${fileName}`)
        .pipe(replace('templateUrl: \\'', `templateUrl: \\'/bin/ngtemplate?path=/apps/${projectName}/components/content/\${componentDir}/`))
        .pipe(gulp.dest(`src/main/content/jcr_root/apps/${projectName}/components/content/\${componentDir}`));
    }))
}));

gulp.task('system-config:aem', gulp.series(() => {
    return gulp.src(['src/template/systemjs.config.js'])
    .pipe(replace('\${DESIGN_PATH}', '/etc/designs/${projectName}/lib/'))
    .pipe(replace('\${APP_PATH}', '/apps/${projectName}/components/content'))
    .pipe(gulp.dest(appConfig.systemConfigTargetAem));
}));

gulp.task("build:aem", gulp.series('clean-generated-files', 'update-template-path:aem', 'libs:aem', 'system-config:aem', (done) => {
    console.log(" ****************** UI BUILD (AEM) COMPETED ****************** ");
    done();
}));