import {Component} from "@angular/core";
import {OnInit} from "@angular/core";

@Component({
    selector: 'about',
    templateUrl: 'about.html'
})
export class AboutComponent implements OnInit {

    ngOnInit() {

    }
}