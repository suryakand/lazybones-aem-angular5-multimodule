package com.suryakand.aem.ng2_aem_sample.core.servlets;
public class SolrConstants {
  
  public static final String PATH_DES = "path_des";
  public static final String PATH_EXACT = "path_exact";
  public static final String PATH_COLLAPSED = "path_collapsed";
}